# Camera update — 2026-10-01

Added an explicit in-app camera preview, capture, retake and confirmation flow. Uses `getUserMedia` over HTTPS, asks only for video, prefers the rear camera, and offers front/rear switching. A native `capture="environment"` file input and an independent gallery input remain available if browser camera access is unavailable or declined.

The confirmed photo is converted to JPEG and passed to the app's existing image-processing handler. No picture is applied when cancelling. Camera tracks are stopped on confirmation, close, backgrounding, switching, page exit, and late permission results after cancellation. No camera image is uploaded by this feature. Existing storage formats and keys are unchanged.

Verification: capture lifecycle and error paths tested with mocked media devices, permission refusal and late permission completion, JPEG handoff, close/focus restoration, nested-dialog Escape; browser checks on five application entry points, real image-file handoff and previews; wardrobe photo persistence verified after reloading; 390px viewport layout inspected. Physical iPhone/Android cameras are not available in this execution environment, so real-device capture has not been verified.

The reading app and food app keep their original processing behavior: their photos are temporary; the storage, wardrobe, and travel apps save photos with records locally in the browser. Recognition coverage and OCR quality are unchanged.
