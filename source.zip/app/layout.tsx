import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "あるもので｜わが家の食材からレシピ",
  description: "手元の食材から、今日作れるレシピと買い足し案を。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}
