import * as tf from '@tensorflow/tfjs';
import * as coco from '@tensorflow-models/coco-ssd';
let model:Promise<coco.ObjectDetection>|undefined;
const map:Record<string,string>={broccoli:'broccoli',carrot:'carrot',apple:'apple',banana:'banana',orange:'orange'};
export async function detectFood(img:HTMLImageElement){
 if(!model) model=(async()=>{await tf.ready();return coco.load({base:'lite_mobilenet_v2'})})().catch(e=>{model=undefined;throw e});
 const detector=await model;const predictions=await detector.detect(img,30,.5);return [...new Set(predictions.map(p=>map[p.class]).filter(Boolean))];
}
